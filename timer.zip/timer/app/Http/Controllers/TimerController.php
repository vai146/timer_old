<?php

namespace App\Http\Controllers;

use Session;
use Illuminate\Http\Request;
use App\Models\Timer;

class TimerController extends Controller
{
    public function create(){
        return view('timer.create');
    }

    public function store(Request $request)
    {
        $timer_id ='1';
        $timer = Timer::findOrNew($timer_id);
        $timer->launch_date = $request->date_time;
        $timer->save();
        return redirect()->route('timer.view')->with('success','Timer has been updated successfully!');
    }

    public function view(){
        $timer = Timer::first();
        return view('timer.view',compact('timer'));
    }
}
